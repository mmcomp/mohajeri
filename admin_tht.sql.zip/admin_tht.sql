-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 16, 2016 at 08:04 PM
-- Server version: 5.5.31
-- PHP Version: 5.3.29

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `admin_tht`
--

-- --------------------------------------------------------

--
-- Table structure for table `avail_request`
--

CREATE TABLE IF NOT EXISTS `avail_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_city` varchar(3) COLLATE utf8_persian_ci NOT NULL,
  `to_city` varchar(3) COLLATE utf8_persian_ci NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `btarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `req_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `stat` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=27 ;

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iata` varchar(4) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `en_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=193 ;

-- --------------------------------------------------------

--
-- Table structure for table `class_ghimat`
--

CREATE TABLE IF NOT EXISTS `class_ghimat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(3) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `airline_iata` varchar(3) NOT NULL,
  `ghimat` int(11) NOT NULL,
  `ghimat_chd` int(11) NOT NULL,
  `ghimat_inf` int(11) NOT NULL,
  `avarez_foroodgah` int(11) NOT NULL,
  `avarez_shahrdari` int(11) NOT NULL,
  `avarez_foroodgah_child` int(11) NOT NULL,
  `avarez_foroodgah_infant` int(11) NOT NULL,
  `avarez_shahrdari_child` int(11) NOT NULL,
  `avarez_shahrdari_infant` int(11) NOT NULL,
  `avarez_helal` int(11) NOT NULL,
  `avarez_helal_child` int(11) NOT NULL,
  `avarez_helal_infant` int(11) NOT NULL,
  `can_cancel` tinyint(1) NOT NULL DEFAULT '1',
  `currency` varchar(5) NOT NULL DEFAULT 'IRR',
  `from_city` varchar(3) NOT NULL,
  `to_city` varchar(3) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3116 ;

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE IF NOT EXISTS `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fa_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `en_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `code` varchar(4) COLLATE utf8_persian_ci NOT NULL,
  `one_in_rial` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE IF NOT EXISTS `flight` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agency_id` int(11) NOT NULL,
  `from_city` varchar(4) COLLATE utf8_persian_ci NOT NULL,
  `to_city` varchar(4) COLLATE utf8_persian_ci NOT NULL,
  `flight_number` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `flight_id` int(11) NOT NULL,
  `fdate` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `ftime` varchar(10) COLLATE utf8_persian_ci NOT NULL DEFAULT '00:00:00',
  `ltime` varchar(10) COLLATE utf8_persian_ci NOT NULL,
  `capacity` int(11) NOT NULL,
  `class_ghimat` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `class` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `typ` int(11) NOT NULL,
  `en` tinyint(1) NOT NULL DEFAULT '0',
  `agency_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `agency_site` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `buy_time` int(11) NOT NULL DEFAULT '10',
  `source_id` int(11) NOT NULL DEFAULT '1' COMMENT 'منبع',
  `tflight` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `fdate` (`fdate`),
  KEY `from_city` (`from_city`),
  KEY `to_city` (`to_city`),
  KEY `source_id` (`source_id`),
  KEY `en` (`en`),
  KEY `tflight_2` (`tflight`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=461655 ;

-- --------------------------------------------------------

--
-- Table structure for table `flight_extra`
--

CREATE TABLE IF NOT EXISTS `flight_extra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `airline` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `airplane` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `description` text COLLATE utf8_persian_ci NOT NULL,
  `extra` int(11) NOT NULL,
  `excurrency` int(11) NOT NULL,
  `extrad` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `price` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `public` int(11) NOT NULL,
  `poursant` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `add_price` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `taxd` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `no_public` int(11) NOT NULL,
  `open_price` int(11) NOT NULL,
  `open_price_currency` int(11) NOT NULL,
  `bfid` int(11) NOT NULL DEFAULT '0',
  `target_capa` int(11) NOT NULL DEFAULT '0',
  `en` tinyint(1) NOT NULL DEFAULT '0',
  `source_id` int(11) NOT NULL DEFAULT '1',
  `flight_id` int(11) NOT NULL,
  `tell_time` int(11) NOT NULL DEFAULT '0',
  `tflight` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `source_id` (`source_id`),
  KEY `en` (`en`),
  KEY `tflight_2` (`tflight`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=495179 ;

--
-- Triggers `flight_extra`
--
DROP TRIGGER IF EXISTS `ondel_flight_extra`;
DELIMITER //
CREATE TRIGGER `ondel_flight_extra` AFTER DELETE ON `flight_extra`
 FOR EACH ROW delete from flight_specific_value where tflight = OLD.tflight and OLD.source_id!=1 LIMIT 1
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `RB_QueueReserve_TBL`
--

CREATE TABLE IF NOT EXISTS `RB_QueueReserve_TBL` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `SenderIP` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `Request` varchar(500) COLLATE utf8_persian_ci DEFAULT NULL,
  `Req_Time` datetime DEFAULT NULL,
  `Type` tinyint(1) NOT NULL,
  `Priority` tinyint(1) NOT NULL,
  `Result` int(1) DEFAULT '0',
  `Reserve_Id` int(11) DEFAULT '0',
  `Respons_Value` varchar(1000) COLLATE utf8_persian_ci DEFAULT NULL,
  `FirstSign` varchar(20) COLLATE utf8_persian_ci NOT NULL DEFAULT '0',
  `SecSign` varchar(20) COLLATE utf8_persian_ci NOT NULL DEFAULT '0',
  `AirLine` varchar(20) COLLATE utf8_persian_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=442 ;

-- --------------------------------------------------------

--
-- Table structure for table `RB_ReqLogs_TBL`
--

CREATE TABLE IF NOT EXISTS `RB_ReqLogs_TBL` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `RequestIP` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `RequestTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Request` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Id_UNIQUE` (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `RB_Request`
--

CREATE TABLE IF NOT EXISTS `RB_Request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request` mediumtext COLLATE utf8_persian_ci,
  `source_id` int(11) NOT NULL,
  `stat` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=5265 ;

-- --------------------------------------------------------

--
-- Table structure for table `RB_SysCMD_TBL`
--

CREATE TABLE IF NOT EXISTS `RB_SysCMD_TBL` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CMD` varchar(50) COLLATE utf8_persian_ci NOT NULL COMMENT 'Application Commands',
  `Sys_Date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=65 ;

-- --------------------------------------------------------

--
-- Table structure for table `RB_Total_Cost`
--

CREATE TABLE IF NOT EXISTS `RB_Total_Cost` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Voucher_Id` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `Total` int(11) NOT NULL DEFAULT '0',
  `Fare` int(11) NOT NULL DEFAULT '0',
  `Tfc` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `voucher_id_UNIQUE` (`Voucher_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `reserve_tmp`
--

CREATE TABLE IF NOT EXISTS `reserve_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` int(11) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `source_id` int(11) NOT NULL,
  `flight_id` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `bflight_id` varchar(100) COLLATE utf8_persian_ci NOT NULL DEFAULT '0',
  `ncap` int(11) NOT NULL,
  `bncap` int(11) NOT NULL DEFAULT '0',
  `class_ghimat` varchar(5) COLLATE utf8_persian_ci NOT NULL,
  `adl` int(11) NOT NULL,
  `chd` int(11) NOT NULL,
  `inf` int(11) NOT NULL,
  `ip` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `agency_id` int(11) NOT NULL,
  `first_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `first_out` text COLLATE utf8_persian_ci NOT NULL,
  `second_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `second_out` text COLLATE utf8_persian_ci NOT NULL,
  `third_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `third_out` text COLLATE utf8_persian_ci NOT NULL,
  `refrence_id` int(11) NOT NULL,
  `voucher_id` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `extra` mediumtext COLLATE utf8_persian_ci NOT NULL COMMENT 'پارامترهای اضافه جهت بلیت',
  `tflight` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `btflight` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `refrence_id` (`refrence_id`),
  KEY `tflight` (`tflight`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=3415 ;

-- --------------------------------------------------------

--
-- Table structure for table `source_table`
--

CREATE TABLE IF NOT EXISTS `source_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ticket_link` varchar(1000) NOT NULL,
  `child_persent` int(11) NOT NULL DEFAULT '50',
  `infant` int(11) NOT NULL DEFAULT '10',
  `service_type` int(11) NOT NULL DEFAULT '1' COMMENT 'یک یعنی سیستمی و دو یعنی مبلغ',
  `extra` text NOT NULL,
  `customer_id` int(11) NOT NULL DEFAULT '-1',
  `source_type` int(1) NOT NULL DEFAULT '1' COMMENT 'یک یعنی پرواز دو یعنی هتل',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Table structure for table `source_update`
--

CREATE TABLE IF NOT EXISTS `source_update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_city` varchar(3) COLLATE utf8_persian_ci NOT NULL,
  `to_city` varchar(3) COLLATE utf8_persian_ci NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `source_id` int(11) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `stat` int(1) NOT NULL DEFAULT '1' COMMENT 'یک یعنی آپدیت شده و صفر درخواست آپدیت و دو در حال آپدیت توسط سورس',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=58 ;

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE IF NOT EXISTS `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refrence_id` int(11) NOT NULL,
  `reserve_tmp_id` int(11) NOT NULL,
  `ticket_number` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `ticket_number2` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `fname` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `lname` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `fname_en` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `lname_en` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `age` varchar(3) COLLATE utf8_persian_ci NOT NULL,
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `gender` int(11) NOT NULL DEFAULT '1',
  `shomare_melli` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `shomare_passport` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `passport_engheza` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `doc_type` int(1) NOT NULL COMMENT '3: national , 1:Passport ',
  `name_prefix` varchar(5) COLLATE utf8_persian_ci NOT NULL,
  `passport_issue_country` varchar(3) COLLATE utf8_persian_ci NOT NULL,
  `nationality` varchar(3) COLLATE utf8_persian_ci NOT NULL,
  `mobile` varchar(11) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `room_id` int(11) NOT NULL,
  `room_number` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `refrence_id` (`refrence_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=6883 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
